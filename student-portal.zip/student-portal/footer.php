</main>
<footer class="footer">
<div class="container">&copy; <?php echo date('Y'); ?> Student Portal</div>
</footer>
</body>
</html>